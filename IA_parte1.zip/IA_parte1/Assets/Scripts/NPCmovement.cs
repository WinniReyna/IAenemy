﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCmovement : MonoBehaviour
{
    //move
    public GameObject[] waypoints;
    private int current = 0;
    float rotspeed;
    public float speed;
    float WPradius = 1;

    //follow
    public Transform[] target;
    private int currentFollow = 0;

    //bools
    private bool moveBool = true;
    private bool followBool = false;

    //Health
    public float health;
    public float maxHealth;

    void Start()
    {
        health = maxHealth;
    }//Start

    void Update()
    {
        Health();

        if (moveBool == true)
        {
            Move();
        }
        if(followBool == true)
        {
            Follow();
        }
    }//Update

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Player")
        {
            health -= 25;
        }
    }//CollisionEnter

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Move")
        {
            moveBool = true;
            followBool = false;
        }

        if (other.gameObject.tag == "Follow")
        {
            moveBool = false;
            followBool = true;
        }
    }//TriggerEnter

    void Move()
    {
        if (Vector3.Distance(waypoints[current].transform.position, transform.position) < WPradius)
        {
            current++;
            if (current >= waypoints.Length)
            {
                current = 0;
            }
        }

        transform.position = Vector3.MoveTowards(transform.position, waypoints[current].transform.position, Time.deltaTime * speed);
    }//Move

    void Follow()
    {
        if (transform.position != target[currentFollow].position)
        {
            Vector3 pos = Vector3.MoveTowards(transform.position, target[currentFollow].position, speed * Time.deltaTime);
            GetComponent<Rigidbody>().MovePosition(pos);
        }
        else currentFollow = (currentFollow + 1) % target.Length;
    }//Follow

    void Health()
    {
        if (health <= 0)
        {
            Destroy(gameObject);
        }
    }//Health
}
