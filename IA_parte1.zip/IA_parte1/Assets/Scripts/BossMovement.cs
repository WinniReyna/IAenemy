﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossMovement : MonoBehaviour
{
    //Desappear
    public GameObject Obj;

    //move
    public GameObject[] waypoints;
    private int current = 0;
    float rotspeed;
    public float speed;
    float WPradius = 1;

    //follow
    public Transform[] target;
    private int currentFollow = 0;

    //bools
    private bool moveBool = false;
    private bool followBool = false;

    //Shoot
    public Transform player;
    public float range = 50.0f;
    public float bulletImpulse = 20.0f;
    private bool onRange = false;
    public Rigidbody projectile;

    //Health
    public float health;
    public float maxHealth;
    public GameObject healthBarUI;
    public Slider slider;

    void Start()
    {
        float rand = Random.Range(1.0f, 2.0f);
        InvokeRepeating("Shoot", 2, rand);

        health = maxHealth;
        slider.value = health / maxHealth;
    }//Start

    void Update()
    {
        onRange = Vector3.Distance(transform.position, player.position) < range;

        MeshRenderer mesh = Obj.GetComponent<MeshRenderer>();
        mesh.enabled = PlayerMovement.state;

        if (onRange)
        {
            transform.LookAt(player);
        }

        Health();

        if(health > 50)
        {
            Move();
        }

        if (health <= 50)
        {
            Follow();
        }
    }//Update

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Player")
        {
            health -= 25;
        }
    }//CollisionEnter

    void Follow()
    {
        if (transform.position != target[currentFollow].position)
        {
            Vector3 pos = Vector3.MoveTowards(transform.position, target[currentFollow].position, speed * Time.deltaTime);
            GetComponent<Rigidbody>().MovePosition(pos);
        }
        else currentFollow = (currentFollow + 1) % target.Length;
    }//Follow

    void Shoot()
    {

        if (onRange)
        {

            Rigidbody bullet = (Rigidbody)Instantiate(projectile, transform.position + transform.forward, transform.rotation);
            bullet.AddForce(transform.forward * bulletImpulse, ForceMode.Impulse);

            Destroy(bullet.gameObject, 2);
        }


    }//Shoot

    void Move()
    {
        if (Vector3.Distance(waypoints[current].transform.position, transform.position) < WPradius)
        {
            current++;
            if (current >= waypoints.Length)
            {
                current = 0;
            }
        }

        transform.position = Vector3.MoveTowards(transform.position, waypoints[current].transform.position, Time.deltaTime * speed);
    }//Move

    void Health()
    {
        slider.value = health / maxHealth;

        if (health < maxHealth)
        {
            healthBarUI.SetActive(true);
        }

        if (health <= 0)
        {
            Destroy(gameObject);
        }

        if (health > maxHealth)
        {
            health = maxHealth;
        }

    }//Health

}

    

