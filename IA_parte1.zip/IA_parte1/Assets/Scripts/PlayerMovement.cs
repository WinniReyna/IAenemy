﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{

    //Move
    public int speed;

    //Health
    public static float health;
    public float maxHealth;
    public GameObject healthBarUI;
    public Slider slider;

    //Bool
    public static bool state = true;

    void Start()
    {
        health = maxHealth;
        slider.value = health/maxHealth;
    }//Start

    void Update()
    {
        Move();
        Health();
    }//update

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Bullet")
        {
            health -= 25;
        }

        if (col.gameObject.tag == "Disappear")
        {
            state = false;
        }

        if (col.gameObject.tag == "NPC")
        {
            health -= 5;
        }
    }//CollisionEnter

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Appear")
        {
            state = true;
        }
    }//TriggerEnter

    void Move()
    {
        Vector3 Movement = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));

        this.transform.position += Movement * speed * Time.deltaTime;
    }//Move

    void Health() 
    {
        slider.value = health / maxHealth;

        if(health < maxHealth)
        {
            healthBarUI.SetActive(true);
        }

        if(health <= 0)
        {
            Destroy(gameObject);
        }

        if(health > maxHealth)
        {
            health = maxHealth;
        }

    }//Health

}
